package com.harbinger.jason;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;



@SpringBootApplication
public class SpringBootJasonApplication {
	public static void main(String[] args) {
		SpringApplication.run(SpringBootJasonApplication.class, args);
	}
}