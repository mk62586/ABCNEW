package com.harbinger.jason;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootJasonApplicationTests {

	@Test
	void contextLoads() {
	}

}
